#!/bin/sh

if [ "$SGE_ROOT" = "" ]; then
  echo "Please source \$SGE_ROOT/\$SGE_CELL/common/settings.(c)sh !"
  exit 1
fi   

if [ "$ARCH" = "" ]; then
    ARCH=`$SGE_ROOT/util/arch`
fi

if [ "$UGE_REST_ROOT" = "" ]; then
    UGE_REST_ROOT=$SGE_ROOT/ugerest
fi

# BASEDIR=`dirname $0`
# BASEDIR=`cd $BASEDIR; pwd`

# . $BASEDIR/../run_util.sh

PRE_ARGS=""
POST_ARGS=""
POSTPOST_ARGS=""
GENERAL_ARGS=true

while [ "$GENERAL_ARGS" = "true" -a $# -gt 0 ]; do
  case $1 in
    --) GENERAL_ARGS=false;;
    -p) POSTPOST_ARGS="-p $2"; shift;;
    -ns) POSTPOST_ARGS="-ns";;
#    *)  echo "Unkonwn option $1"; exit 1;;
  esac
  shift
done

POST_ARGS="-i ${SGE_ROOT}/${SGE_CELL}/common/ugerest.pid -u bootstrap://${SGE_ROOT}@${SGE_CELL}:${SGE_QMASTER_PORT}"
POSTPOST_ARGS="$POSTPOST_ARGS $*"

PRE_ARGS="$PRE_ARGS -Djava.util.logging.config.file=$SGE_ROOT/ugerest/conf/logging.properties"
PRE_ARGS="$PRE_ARGS -Djava.security.auth.login.config=$SGE_ROOT/ugerest/conf/jaas.config"
PRE_ARGS="$PRE_ARGS -Dcom.sun.grid.jgdi.sgeRoot=$SGE_ROOT"
PRE_ARGS="$PRE_ARGS -Dcom.univa.ugerest.docRoot=$UGE_REST_ROOT/htdocs"
PRE_ARGS="$PRE_ARGS -Djava.library.path=$SGE_ROOT/lib/$ARCH"

if [ "$SGE_ROOT" != "" ]; then
   CP=$SGE_ROOT/lib/jgdi.jar:$SGE_ROOT/lib/juti.jar:$SGE_ROOT/lib/drmaa.jar
fi

#echo "READLINE_JAVA_JAR: $READLINE_JAVA_JAR"
#echo "READLINE_LIB_PATH: $READLINE_LIB_PATH"

if [ "$READLINE_JAVA_JAR" != "" ]; then
   CP="$CP:$READLINE_JAVA_JAR"
fi

if [ "$READLINE_LIB_PATH" ]; then
   if [ "$LD_LIBRARY_PATH" = "" ]; then
        LD_LIBRARY_PATH=$READLINE_LIB_PATH
   else
        LD_LIBRARY_PATH="$LD_LIBRARY_PATH:$READLINE_LIB_PATH"
   fi
fi

if [ $ARCH = "darwin-x86" -o $ARCH = "darwin-ppc" -o $ARCH = "darwin-x64" ]; then
   PRE_ARGS="$PRE_ARGS -Djava.awt.headless=true"
   DYLD_LIBRARY_PATH=$LD_LIBRARY_PATH:$DYLD_LIBRARY_PATH
   export DYLD_LIBRARY_PATH
fi   

if [ $ARCH = "aix51" ]; then
   LIBPATH=$LD_LIBRARY_PATH:$LIBPATH
   export LIBPATH 
fi   


POST_ARGS="$POST_ARGS $POSTPOST_ARGS"

#echo "-------"
#echo $POST_ARGS
#echo "-------"


RESTCP=\
$UGE_REST_ROOT/lib/xmemcached-1.2.6.1.jar:\
$UGE_REST_ROOT/lib/org.json.jar:\
$UGE_REST_ROOT/lib/org.restlet.jar:\
$UGE_REST_ROOT/lib/org.restlet.ext.json.jar:\
$UGE_REST_ROOT/lib/org.restlet.ext.swagger.jar:\
$UGE_REST_ROOT/lib/org.restlet.ext.apispark.jar:\
$UGE_REST_ROOT/lib/org.restlet.ext.jackson.jar:\
$UGE_REST_ROOT/lib/org.restlet.ext.ssl.jar:\
$UGE_REST_ROOT/lib/org.restlet.ext.jaas.jar:\
$UGE_REST_ROOT/lib/org.restlet.ext.oauth.jar:\
$UGE_REST_ROOT/lib/org.restlet.ext.jsslutils.jar:\
$UGE_REST_ROOT/lib/org.jsslutils_1.0/org.jsslutils.jar:\
$UGE_REST_ROOT/lib/commons-cli-1.2.jar:\
$UGE_REST_ROOT/lib/org.restlet.ext.jetty.jar:\
$UGE_REST_ROOT/lib/javax.servlet.jar:\
$UGE_REST_ROOT/lib/org.eclipse.jetty.ajp.jar:\
$UGE_REST_ROOT/lib/org.eclipse.jetty.server.jar:\
$UGE_REST_ROOT/lib/org.eclipse.jetty.client.jar:\
$UGE_REST_ROOT/lib/org.eclipse.jetty.util.jar:\
$UGE_REST_ROOT/lib/org.eclipse.jetty.http.jar:\
$UGE_REST_ROOT/lib/org.eclipse.jetty.io.jar:\
$UGE_REST_ROOT/lib/org.eclipse.jetty.continuations.jar:\
$UGE_REST_ROOT/lib/com.fasterxml.jackson.annotations.jar:\
$UGE_REST_ROOT/lib/com.fasterxml.jackson.core.jar:\
$UGE_REST_ROOT/lib/com.fasterxml.jackson.csv.jar:\
$UGE_REST_ROOT/lib/com.fasterxml.jackson.databind.jar:\
$UGE_REST_ROOT/lib/com.fasterxml.jackson.jaxb.jar:\
$UGE_REST_ROOT/lib/com.fasterxml.jackson.jsonschema.jar:\
$UGE_REST_ROOT/lib/com.fasterxml.jackson.smile.jar:\
$UGE_REST_ROOT/lib/com.fasterxml.jackson.xml.jar:\
$UGE_REST_ROOT/lib/com.fasterxml.jackson.yaml.jar:\
$UGE_REST_ROOT/lib/ugerestapi.jar:\
$UGE_REST_ROOT/conf

CP=${RESTCP}:${CP}

# check Java version
JV=`java -version 2>&1 | grep version | cut -f 3,3 -d ' ' | tr -d '"'  | cut -f 1,2 -d .`
JVMAJOR=`echo $JV | cut -f 2,2 -d .`
if [ $JVMAJOR -lt 7 ]; then
    echo "Your Java version must be 1.7 but is $JV"
    exit 1
fi    

# echo "java $PRE_ARGS -cp $CP com.univa.ugerest.UgeRestMain -u bootstrap://${SGE_ROOT}@${SGE_CELL}:${SGE_QMASTER_PORT} "
#echo java $PRE_ARGS -cp $CP com.univa.ugerest.UgeRestMain $POST_ARGS
java $PRE_ARGS -cp $CP com.univa.ugerest.UgeRestMain $POST_ARGS &

echo $! > $UGE_REST_ROOT/conf/pid_file
