#!/bin/sh

echo "$*"

if [ $# != 2 ]; then
    echo "Usage: $0 <user> <baseurl>"
    exit 1
fi    

if [ "$1" = "none" ]; then
   USERARG=""
else
   USERARG="-u $1"
fi

BASEURL=$2

echo "curl_test.sh $USERARG $BASEURL"

# add a queue test via curl
curl -X POST -H "Content-Type: application/json" $BASEURL/clusterqueues -d '{"qname":"test.q", "hostlist":["@allhosts"], "seq_no":[{"hostgroup":"@/","value":0},{"hostgroup":"amiata","value":2}], "load_thresholds":[{"hostgroup":"@/","value":[{"name":"np_load_avg","value":1.75}]}], "suspend_thresholds":[ {"hostgroup":"@/","value":[{"name":"np_load_avg", "value":1.25}]}, {"hostgroup":"amiata", "value":[{"name":"np_load_avg","value":1.35}]} ], "nsuspend":[{"hostgroup":"@/","value":1},{"hostgroup":"amiata", "value":5}], "suspend_interval":[{"hostgroup":"@/","value":"00:05:00"},{"hostgroup":"amiata","value":"00:01:00"}], "priority":[{"hostgroup":"@/","value":"0"},{"hostgroup":"amiata","value":"10"}], "min_cpu_interval":[{"hostgroup":"@/","value":"00:05:00"},{"hostgroup":"amiata","value":"00:01:00"}], "qtype":[{"hostgroup":"@/","value":"BATCH INTERACTIVE"}], "ckpt_list":[{"hostgroup":"@/","value":["testcheckpointobject"]}], "pe_list":[{"hostgroup":"@/", "value":["make"]}], "jc_list":[{"hostgroup":"@/", "value":["NO_JC","ANY_JC"]}], "rerun":[{"hostgroup":"@/", "value":FALSE}], "slots":[{"hostgroup":"@/", "value":1}], "tmpdir":[{"hostgroup":"@/", "value":"/tmp"}], "shell":[{"hostgroup":"@/", "value":"/bin/csh"}], "prolog":[{"hostgroup":"@/", "value":""}], "epilog":[{"hostgroup":"@/", "value":""}], "shell_start_mode":[{"hostgroup":"@/", "value":"unix_behavior"}], "starter_method":[{"hostgroup":"@/", "value":""}], "suspend_method":[{"hostgroup":"@/", "value":""}], "resume_method":[{"hostgroup":"@/", "value":""}], "terminate_method":[{"hostgroup":"@/", "value":""}], "notify":[{"hostgroup":"@/", "value":"00:00:60"}], "owner_list":[{"hostgroup":"@/", "value":[]}], "user_lists":[{"hostgroup":"@/", "value":[]}], "xuser_lists":[{"hostgroup":"@/", "value":[]}], "subordinate_list":[{"hostgroup":"@/", "value":[]}], "complex_values":[{"hostgroup":"@/", "value":[]}], "projects":[{"hostgroup":"@/", "value":[]}], "xprojects":[{"hostgroup":"@/", "value":[]}], "calendar":[{"hostgroup":"@/", "value":"NONE"}], "initial_state":[{"hostgroup":"@/", "value":"default"}], "s_rt":[{"hostgroup":"@/", "value":"INFINITY"}], "h_rt":[{"hostgroup":"@/", "value":"INFINITY"}], "d_rt":[{"hostgroup":"@/", "value":"INFINITY"}], "s_cpu":[{"hostgroup":"@/", "value":"INFINITY"}], "h_cpu":[{"hostgroup":"@/", "value":"INFINITY"}], "s_fsize":[{"hostgroup":"@/", "value":"INFINITY"}], "h_fsize":[{"hostgroup":"@/", "value":"INFINITY"}], "s_data":[{"hostgroup":"@/", "value":"INFINITY"}], "h_data":[{"hostgroup":"@/", "value":"INFINITY"}], "s_stack":[{"hostgroup":"@/", "value":"INFINITY"}], "h_stack":[{"hostgroup":"@/", "value":"INFINITY"}], "s_core":[{"hostgroup":"@/", "value":"INFINITY"}], "h_core":[{"hostgroup":"@/", "value":"INFINITY"}], "s_rss":[{"hostgroup":"@/", "value":"INFINITY"}], "h_rss":[{"hostgroup":"@/", "value":"INFINITY"}], "s_vmem":[{"hostgroup":"@/", "value":"INFINITY"}], "h_vmem":[{"hostgroup":"@/", "value":"INFINITY"}]}' $USERARG

if [ $? != 0 ]; then
    echo "curl add clusterqueue failed"
    exit 1
fi
# echo newline
echo

# wait 2s
sleep 2
# get the newly created clusterqueue
curl $BASEURL/clusterqueues/test.q $USERARG

if [ $? != 0 ]; then
    echo "curl get clusterqueue failed"
    exit 1
fi
# echo newline
echo

# delete the clusterqeue test.q
curl -X DELETE -H "Content-Type: application/json" $BASEURL/clusterqueues -d '{"qname":"test.q"}' $USERARG

if [ $? != 0 ]; then
    echo "curl delete clusterqueue failed"
    exit 1
fi
# echo newline
echo
